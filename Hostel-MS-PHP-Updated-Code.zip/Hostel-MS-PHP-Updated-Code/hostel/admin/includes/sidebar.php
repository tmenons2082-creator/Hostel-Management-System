<nav class="ts-sidebar" id="hms-sidebar" aria-label="Admin navigation">
	<ul class="ts-sidebar-menu">
		<li class="ts-label">Overview</li>
		<li><a href="dashboard.php"><i class="bi bi-speedometer2" aria-hidden="true"></i> Dashboard</a></li>

		<li class="ts-label">Academics</li>
		<li><a href="#"><i class="bi bi-journal-bookmark" aria-hidden="true"></i> Courses</a>
			<ul>
				<li><a href="add-courses.php">Add Courses</a></li>
				<li><a href="manage-courses.php">Manage Courses</a></li>
			</ul>
		</li>

		<li><a href="#"><i class="bi bi-door-open" aria-hidden="true"></i> Rooms</a>
			<ul>
				<li><a href="create-room.php">Add Room</a></li>
				<li><a href="manage-rooms.php">Manage Rooms</a></li>
			</ul>
		</li>

		<li class="ts-label">Students</li>
		<li><a href="registration.php"><i class="bi bi-person-plus" aria-hidden="true"></i> Student Registration</a></li>
		<li><a href="manage-students.php"><i class="bi bi-people" aria-hidden="true"></i> Manage Students</a></li>

		<li class="ts-label">Service Desk</li>
		<li><a href="#"><i class="bi bi-chat-left-text" aria-hidden="true"></i> Complaints</a>
			<ul>
				<li><a href="new-complaints.php">New</a></li>
				<li><a href="inprocess-complaints.php">In Process</a></li>
				<li><a href="closed-complaints.php">Closed</a></li>
				<li><a href="all-complaints.php">All</a></li>
			</ul>
		</li>

		<li><a href="#"><i class="bi bi-star" aria-hidden="true"></i> Feedback</a>
			<ul>
				<li><a href="feedbacks.php">All Feedback</a></li>
			</ul>
		</li>

		<li class="ts-label">Audit</li>
		<li><a href="access-log.php"><i class="bi bi-clock-history" aria-hidden="true"></i> User Access Logs</a></li>
	</ul>
</nav>
